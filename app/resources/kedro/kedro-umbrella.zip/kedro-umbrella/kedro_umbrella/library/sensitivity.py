import random
import torch
import numpy as np
import captum
import matplotlib.pyplot as plt

from .utils import ReportDir

import matplotlib

matplotlib.use("Agg")

# Variable parameters
NUM_SAMPLE = 1  # number of samples to perform sensitivity analysis
TARGET = 0
DIFF_STEP = 10
GRID_SIZE = 1000
REPORT_DIR = "empty"

def find_most_sensitive_feature(
    model, low, high, num_features, target=0, method="kernel-shap", num_sample=100
):
    random_np = np.random.uniform(low=low, high=high, size=(num_sample, num_features))

    random_tensor = torch.tensor(random_np).float()

    if method == "ig":
        interp = captum.attr.IntegratedGradients(model)
        attributions = interp.attribute(random_tensor, baselines=0, target=target)
    elif method == "kernel-shap":
        interp = captum.attr.KernelShap(model)
        attributions = interp.attribute(random_tensor, baselines=0, n_samples=100)
    else:
        raise ValueError(f"Unknown method: {method}")
    attributions = attributions.detach().numpy()
    return attributions, random_tensor


def plot_attributions(attributions):
    nb = init_incr_static_cnt(plot_attributions)

    plt.figure()
    plt.imshow(
        attributions.T,
        cmap=plt.cm.seismic,  # pylint: disable=no-member
        interpolation="nearest",
        aspect="auto",
    )
    plt.colorbar(shrink=0.7)
    plt.xlabel("Sample Index")
    plt.ylabel("Feature Index")
    plt.title("Feature Attributions")
    plt.tight_layout()
    plt.show()

    plt.savefig(f"{REPORT_DIR}/attribution_{nb}.png")


def aggregate_attributions(attributions, a_abs=True):
    attr = np.abs(attributions) if a_abs else attributions
    attr_by_sample = attr.sum(1)
    top_samples_idx = np.argsort(attr_by_sample)[::-1]
    attr_by_feature = attr.sum(0)
    top_feature_idx = np.argsort(attr_by_feature)[::-1]
    return top_samples_idx, top_feature_idx


def compute_query_range(sample, a_min=None, a_max=None, divide=10):
    """
    Computes the query range for a given sample.
    Args:
        sample (torch.Tensor): The sample to divide the range.
        min (float, optional): The minimum value for clamping. Defaults to None.
        max (float, optional): The maximum value for clamping. Defaults to None.
        divide (int, optional): value to narrow down from sample range.
    Returns:
        tuple: A tuple containing two tensors:
            - query_low (torch.Tensor): The lower bound of the query range, clamped to min.
            - query_high (torch.Tensor): The upper bound of the query range, clamped to max.
    """
    sample_ = sample.detach().numpy() if isinstance(sample, torch.Tensor) else sample

    delta = (a_max - a_min) / divide
    query_min = np.clip(sample_ - delta, a_min=a_min, a_max=a_max)
    query_max = np.clip(sample_ + delta, a_min=a_min, a_max=a_max)
    assert np.all(query_min >= a_min) and np.all(query_max <= a_max)
    return query_min, query_max


def difference_metric(grid, diff_type="classification", step=10):
    """
    Define a difference metric between a point and its neighbors to find
    high elevation area surrounded by flat points
    """

    def _do_diff(grid, diff_type, i, j, neighbors):
        if diff_type == "classification":
            # true for any difference
            diff_ = np.abs(grid[i, j] - neighbors) > 0
        elif diff_type == "regression":
            # keep the numerical value
            diff_ = np.abs(grid[i, j] - neighbors)
        else:
            raise ValueError(f"Unknown diff_type: {diff_type}")
        return diff_

    diff = np.zeros_like(grid)
    diff_pos = np.zeros((grid.shape[0], grid.shape[1], 2), dtype=int)
    for i in range(step, grid.shape[0] - step):
        for j in range(step, grid.shape[1] - step):
            neighbor_idx = np.array(
                [
                    (i - step, j),
                    (i + step, j),
                    (i, j - step),
                    (i, j + step),
                    (i - step, j - step),
                    (i - step, j + step),
                    (i + step, j - step),
                    (i + step, j + step),
                ]
            )
            neighbors = grid[neighbor_idx[:, 0], neighbor_idx[:, 1]]
            diff_ = _do_diff(grid, diff_type, i, j, neighbors)
            max_idx = np.argmax(diff_)
            diff_pos[i, j] = neighbor_idx[max_idx]
            diff[i, j] = diff_[max_idx]

    # Shrink grid to avoid sharp diff at boundary
    return diff[step:-step, step:-step], diff_pos[step:-step, step:-step]


def plot_difference(feat1, feat2, grid, labels, diff_step=10):
    nb = init_incr_static_cnt(plot_difference)

    plt.figure()
    plt.contourf(
        feat1[diff_step:-diff_step], feat2[diff_step:-diff_step], grid, levels=256
    )
    plt.axis("scaled")
    plt.colorbar()
    plt.title("Difference plot")
    plt.xlabel(labels[0])
    plt.ylabel(labels[1])
    plt.tight_layout()
    plt.show()

    plt.savefig(f"{REPORT_DIR}/difference_{nb}.png")


def plot_landscape(feat1, feat2, out_reshape, labels):
    nb = init_incr_static_cnt(plot_landscape)

    plt.figure()
    plt.contourf(feat1, feat2, out_reshape, levels=256)
    plt.axis("scaled")
    plt.colorbar()
    plt.title("landscape plot")
    plt.xlabel(labels[0])
    plt.ylabel(labels[1])
    plt.tight_layout()
    plt.show()

    plt.savefig(f"{REPORT_DIR}/landscape_{nb}.png")


def plot_policy(grid_0, grid_1, actions, labels):
    nb = init_incr_static_cnt(plot_policy)

    col = ["red", "green", "blue", "orange"]
    colors = [col[i] for i in actions]

    # Plot the scatter plot
    plt.figure()
    fig, ax = plt.subplots(1, 1, figsize=(5, 5))
    plt.scatter(grid_0.flatten(), grid_1.flatten(), c=colors, s=1)

    # Plot properties
    ax.set_title("FCNN Policy")
    ax.set_xlabel(labels[0])
    ax.set_ylabel(labels[1])
    ax.tick_params(axis="both")

    # Get unique colors and create legend handles and labels
    legend_handles = [
        plt.Line2D(
            [0], [0], marker="o", color="w", markerfacecolor=color, markersize=10
        )
        for color in col
    ]
    legend_labels = ["Do Nothing", "Left", "Main", "Right"]

    # Add legend with custom handles and labels
    plt.legend(legend_handles, legend_labels, prop={"weight": "bold", "size": 10})

    # Adjust the layout to make it look clean
    fig.tight_layout()
    plt.show()
    plt.savefig(f"{REPORT_DIR}/policy_{nb}.png")


def init_incr_static_cnt(function):
    if not hasattr(function, "nb"):
        function.nb = 0  # Initialize the "static" variable
    function.nb += 1
    nb = function.nb
    return nb


def eval_sensitive_features_grid(model, attr_div, random_div, top_samples_div):
    """
    Step 3: Vary the 2 most-sensitive features in a grid and fix the remaining features

    From focus_around_top_samples, we have top_samples_div, the most important samples
    in a small region of the model. Now, we focus on this region and:
    1. identify important features (feat_imp) for random_div on this sub-domain ("div")
    2. generate a dataset varying the two most important features from their min to mesh.
    We create a mesh of GRID_SIZExGRID_SIZE points for it.

    @in: out from focus_around_top_samples
        - code_X, code_Y: code for displ and eps respectively
        - regressor: the regressor X->Y
        - top_samples_div: top-N important samples in sub-region
        - random_div: the random features in the divided domain
        - attr_div: the attributions in the divided domain
    @out:
        plots for model landscape, difference of feature sensitivity
        and values project back in full space
    """
    for sample_idx in top_samples_div[:NUM_SAMPLE]:
        print(
            "\n# Step 3: Vary the 2 most-sensitive features in a grid "
            "and fix the remaining features"
        )

        top_sample_div = random_div[sample_idx]
        print(f"random sample {sample_idx}: {top_sample_div}")
        feat_imp = list(np.argsort(attr_div[sample_idx])[::-1])
        print(f"Feature importance for sample: {feat_imp}")

        # Values to vary
        fixed_feat = feat_imp[2:]
        vary_feat = feat_imp[:2]  # the first two most imp.
        feat1 = np.linspace(
            model.LOW[vary_feat[0]], model.HIGH[vary_feat[0]], GRID_SIZE
        )
        feat2 = np.linspace(
            model.LOW[vary_feat[1]], model.HIGH[vary_feat[1]], GRID_SIZE
        )
        grid_0, grid_1 = np.meshgrid(feat1, feat2)

        # Create the dataset w/ fixed feat and varying features
        dataset = np.zeros((GRID_SIZE * GRID_SIZE, model.NUM_FEATURES))
        dataset[:, fixed_feat] = random_div[sample_idx][list(fixed_feat)]
        dataset[:, vary_feat] = np.vstack((grid_0.flatten(), grid_1.flatten())).T
        dataset_tensor = torch.tensor(dataset, dtype=torch.float32)

        # Calculate model output
        out = model.model(dataset_tensor)
        if out.dim() == 1:
            out_reshape = out.detach().numpy().reshape(GRID_SIZE, GRID_SIZE)
        else:
            out_reshape = out[:, TARGET].detach().numpy().reshape(GRID_SIZE, GRID_SIZE)

        # Policy plot
        print("Plotting regression landscape")
        plot_landscape(feat1, feat2, out_reshape, vary_feat)

        # Plot the difference metric
        print("Plotting difference")
        diff_grid, diff_pos = difference_metric(
            out_reshape, diff_type="regression", step=DIFF_STEP
        )
        plot_difference(feat1, feat2, diff_grid, vary_feat, diff_step=DIFF_STEP)

        if model.has_project_back_to_full_space():
            # Project back to original physics model
            model.project_back_to_full_space(
                dataset.reshape((GRID_SIZE, GRID_SIZE, model.NUM_FEATURES)),
                out.detach().numpy().reshape((GRID_SIZE, GRID_SIZE, out.shape[1])),
                diff_grid,
                diff_pos,
                diff_step=DIFF_STEP,
            )


def focus_around_top_samples(
    model, attributions, random_tensor, top_samples_idx, method="ig"
):
    """
    Step 2: Focus around each of the top-N important samples.

    Vary around the top-N samples by dividing the radius,
    and determine the top-2 most sensitive features in this sub-region.
    - From the original random_tensor sampling, we focus on the top samples (top_samples_idx)
    - Query the model for sensitive areas in a range of 1/10 of the original range of features

    @in:
        regressor: the model to sample
        attributions: the feature attributions
        random_tensor: random samples
        top_samples_idx: top-N important samples
    @out:
      top_samples_div, top-N important samples in sub-region
      random_div, the random features in the divided domain
      attr_div, the attributions in the divided domain
    """
    for sample_idx in top_samples_idx[:NUM_SAMPLE]:
        print(
            f"\n# Step 2: Focus around each of the top-{NUM_SAMPLE} important samples"
        )
        top_sample = random_tensor[sample_idx]
        print(f"Top important sample {sample_idx} in full domain: {top_sample}")
        feat_imp = np.argsort(attributions[sample_idx])[::-1]
        print(f"Feature importance for sample {sample_idx}: {feat_imp}")

        query_min, query_max = compute_query_range(
            top_sample, a_min=model.LOW, a_max=model.HIGH, divide=10
        )
        print(f"Query range: [{query_min}, {query_max}]")

        # attributions on the divided range
        attr_div, random_div = find_most_sensitive_feature(
            model.model,
            low=query_min,
            high=query_max,
            num_features=model.NUM_FEATURES,
            target=TARGET,
            method=method,
            num_sample=GRID_SIZE,
        )
        plot_attributions(attr_div)

        top_samples_div, top_features_div = aggregate_attributions(attr_div)
        print(
            f"Top-{NUM_SAMPLE} important samples (sub-region): {top_samples_div[:NUM_SAMPLE]}"
        )
        print(f"Most important features (sub-domain): {top_features_div}")

        eval_sensitive_features_grid(model, attr_div, random_div, top_samples_div)


def calculate_top_samples(model, method="ig"):
    """
    Step 1: Determine the top-N important samples
    @in:
        regressor: the model to sample
    @out:
        random_tensor: random samples used to find most sensitive features
        top_samples_idx: top-N important samples from random_tensor
        attributions: the feature attributions
    """
    print(f"\n# Step 1: Determine the top-{NUM_SAMPLE} important samples")
    attributions, random_tensor = find_most_sensitive_feature(
        model.model,
        low=model.LOW,
        high=model.HIGH,
        num_features=model.NUM_FEATURES,
        target=TARGET,
        method=method,
        num_sample=GRID_SIZE,
    )

    plot_attributions(attributions)

    top_samples_idx, top_feature_idx = aggregate_attributions(attributions)
    print(
        f"Top-{NUM_SAMPLE} important samples (full-domain): {top_samples_idx[:NUM_SAMPLE]}"
    )
    print(f"Most important features (full-domain): {top_feature_idx}")
    return attributions, random_tensor, top_samples_idx





def set_parameters(params):
    global NUM_SAMPLE, TARGET, DIFF_STEP, GRID_SIZE, REPORT_DIR

    NUM_SAMPLE = params.get("num_sample", NUM_SAMPLE)
    TARGET = params.get("TARGET", TARGET)
    DIFF_STEP = params.get("DIFF_STEP", DIFF_STEP)
    GRID_SIZE = params.get("GRID_SIZE", GRID_SIZE)
    REPORT_DIR = ReportDir(params['_node_name']).get()
    print("# Parameters")
    print(f"NUM_SAMPLE: {NUM_SAMPLE}")
    print(f"TARGET: {TARGET}")
    print(f"DIFF_STEP: {DIFF_STEP}")
    print(f"GRID_SIZE: {GRID_SIZE}")
    print(f"REPORT_DIR: {REPORT_DIR}")

def global_robustness(model_, parameters):
    set_parameters(parameters)

    # TODO make it more generic or part of the librarym for FDF
    model = Model(model_)

    # Step 1: Determine the top-N important samples
    attributions, random_tensor, top_samples_idx = calculate_top_samples(model)

    # Step 2: Focus around each of the top-N important samples.
    focus_around_top_samples(model, attributions, random_tensor, 
                             top_samples_idx)

    return top_samples_idx


class Model:
    # XXX this works only for the cetim case
    NUM_FEATURES = 10  # number of features of model
    LOW = np.array([0] * NUM_FEATURES)  # lowest value of input space x
    HIGH = np.array([16] * NUM_FEATURES)  # highest value of input space x

    def __init__(self, regressor):
        self.model = regressor

    def __call__(self, x):
        return self.model(x)

    def has_project_back_to_full_space(self):
        return False