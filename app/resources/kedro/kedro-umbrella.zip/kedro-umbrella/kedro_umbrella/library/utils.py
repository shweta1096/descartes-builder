import logging
import os
from typing import Any, Dict, Tuple
import numpy as np
import torch
from sklearn.metrics import root_mean_squared_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
import mat73
import scipy.io as sio

import matplotlib.pyplot as plt
import yaml
import os

logger = logging.getLogger(__name__)

class ReportDir:
    REPORT_DIR_PREFIX = "data/08_reporting/"

    def __init__(self, node_name: str):
        self.node_name = node_name
        self.report_dir = ReportDir.REPORT_DIR_PREFIX + node_name
        if not os.path.exists(self.report_dir):
            os.makedirs(self.report_dir)

    def get(self):
        return self.report_dir


def score(Y_test, Y_pred, parameters: Dict[str, Any] = {}):
    def _regression_plot(Y_test, Y_pred):
        logger.info("Generating regression scatter and residual plot...")
        # Scatter plot of actual vs. predicted values
        plt.figure(figsize=(10, 6))
        plt.scatter(Y_test, Y_pred, alpha=0.5)
        plt.title("Actual vs. Predicted Values")
        plt.xlabel("Actual Values")
        plt.ylabel("Predicted Values")
        plt.plot(
            [Y_test.min(), Y_test.max()], [Y_test.min(), Y_test.max()], "k--", lw=4
        )  # Diagonal line
        plt.savefig(f"{REPORT_DIR}/actual_vs_pred.png")

        # Residual plot
        residuals = Y_pred - Y_test
        plt.figure(figsize=(10, 6))
        plt.scatter(Y_test, residuals, alpha=0.5)
        plt.title("Residuals vs. Actual Values")
        plt.xlabel("Actual Values")
        plt.ylabel("Residuals")
        plt.axhline(y=0, color="k", linestyle="--")  # Horizontal line at 0
        plt.savefig(f"{REPORT_DIR}/residual_plot.png")

    def _time_series_plot(Y_test, Y_pred):
        # Test and pred
        plt.figure(figsize=(10, 6))
        plt.plot(Y_test, label="Test")
        plt.plot(Y_pred, label="Prediction")
        plt.title("Test & predictions")
        plt.xlabel("Sample")
        plt.ylabel("Value")
        plt.legend()
        plt.savefig(f"{REPORT_DIR}/test_pred.png")

    REPORT_DIR = ReportDir(parameters['_node_name']).get()

    # compute score values
    Y_test_ = Y_test.numpy() if isinstance(Y_test, torch.Tensor) else Y_test
    Y_pred_ = Y_pred.numpy() if isinstance(Y_pred, torch.Tensor) else Y_pred
    mse = mean_squared_error(Y_test_, Y_pred_)
    rmse = root_mean_squared_error(Y_test_, Y_pred_)
    nrmse = rmse / (np.max(Y_test_) - np.min(Y_test_))
    r2 = r2_score(Y_test_, Y_pred_)
    logger.info(f"MSE = {mse}, NRMSE = {nrmse}, r2 = {r2}")

    # dump score YAML
    score = {
        "mse": float(mse),
        "rmse": float(rmse),
        "nrmse": float(nrmse),
        "r2": float(r2),
    }
    with open(f"{REPORT_DIR}/score.yml", "w") as file:
        yaml.dump(score, file)

    # dump plot
    if parameters.get("plot", None) == "regression":
        _regression_plot(Y_test, Y_pred)
    if parameters.get("plot", None) == "time_series":
        _time_series_plot(Y_test, Y_pred)

    return score["nrmse"], score["r2"]


def load_mat(
    parameters: Dict[str, Any]
) -> Tuple[np.ndarray | list[np.ndarray], np.ndarray | list[np.ndarray]]:
    """
    Load data from a .mat file.

    Args:
        parameters: Additional parameters.

    Returns:
        Tuple of input features and output data.
    """
    data = None
    try:
        data = mat73.loadmat(parameters["data_path"])
    except TypeError as e:
        if "is not a MATLAB 7.3 file" in str(e):
            data = sio.loadmat(parameters["data_path"])
        else:
            logger.error(
                f"Error loading .mat file: {parameters['data_path']}\n{type(e)}: {e}"
            )  # Error will not propagate to the below logger
            raise e
    except Exception as e:
        logger.error(
            f"Error loading .mat file: {parameters['data_path']}\n{type(e)}: {e}"
        )
        raise e

    input_key: str | list[str] = parameters.get("input_key", "input")
    output_key: str | list[str] = parameters.get("output_key", "output")

    X = None
    Y = None

    if isinstance(input_key, str):
        X = data[input_key]
    else:
        X = [data[key] for key in input_key]
    if isinstance(output_key, str):
        Y = data[output_key]
    else:
        Y = [data[key] for key in output_key]

    return X, Y


def split_data(
    X: np.ndarray,
    Y: np.ndarray,
    parameters: Dict[str, Any],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Split data into training and testing sets.

    Args:
        X: Input features.
        Y: Output data.
        parameters: Additional parameters.

    Returns:
        Tuple of X_train, X_test, Y_train, Y_test.
    """
    # Use provided split time or random state
    split_time = parameters.get("split_time", None)
    if split_time:
        X_train, X_test = X[:split_time], X[split_time:]
        Y_train, Y_test = Y[:split_time], Y[split_time:]
        return X_train, X_test, Y_train, Y_test

    X_train, X_test, Y_train, Y_test = train_test_split(
        X,
        Y,
        random_state=parameters.get("random_state", None),
        train_size=parameters.get("train_size", None),
    )
    #if parameters.get("to_torch", False):
    #    X_train = torch.tensor(X_train, dtype=torch.float32)
    #    X_test = torch.tensor(X_test, dtype=torch.float32)
    #    Y_train = torch.tensor(Y_train, dtype=torch.float32)
    #    Y_test = torch.tensor(Y_test, dtype=torch.float32)
    return X_train, X_test, Y_train, Y_test


def load_device(parameters) -> torch.device:
    if torch.backends.mps.is_available():
        device = torch.device("mps")
    elif torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")

    logger.info(f"Loaded device: {device}")

    return device
