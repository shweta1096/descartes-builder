from sklearn.metrics import mean_squared_error, r2_score
import numpy as np
import logging
import mat73
from sklearn.model_selection import train_test_split
from typing import Any, Dict
import matplotlib.pyplot as plt
import yaml

logger = logging.getLogger(__name__)

def _regression_plot(Y_test, Y_pred):
    logger.info("Generating regression scatter and residual plot...")
    # Scatter plot of actual vs. predicted values
    plt.figure(figsize=(10, 6))
    plt.scatter(Y_test, Y_pred, alpha=0.5)
    plt.title('Actual vs. Predicted Values')
    plt.xlabel('Actual Values')
    plt.ylabel('Predicted Values')
    plt.plot([Y_test.min(), Y_test.max()], [Y_test.min(), Y_test.max()], 
             'k--', lw=4) # Diagonal line
    plt.savefig("data/08_reporting/actual_vs_pred.png")

    # Residual plot
    residuals = Y_pred - Y_test
    plt.figure(figsize=(10, 6))
    plt.scatter(Y_test, residuals, alpha=0.5)
    plt.title('Residuals vs. Actual Values')
    plt.xlabel('Actual Values')
    plt.ylabel('Residuals')
    plt.axhline(y=0, color='k', linestyle='--')  # Horizontal line at 0
    plt.savefig("data/08_reporting/residual_plot.png")

def _time_series_plot(Y_test, Y_pred):
    # Test and pred 
    plt.figure(figsize=(10, 6))
    plt.plot(Y_test, label = 'Test')
    plt.plot(Y_pred, label = 'Prediction')
    plt.title('Test & predictions')
    plt.xlabel('Sample')
    plt.ylabel('Value')
    plt.legend()
    plt.savefig("data/08_reporting/test_pred.png")


def score(Y_test, Y_pred, parameters: Dict[str, Any] = {}):
    mse = mean_squared_error(Y_test, Y_pred)
    rmse = mean_squared_error(Y_test, Y_pred, squared=False) #np.sqrt(mse)
    nrmse = rmse / (np.max(Y_test) - np.min(Y_test))
    r2 = r2_score(Y_test, Y_pred)
    logger.info(f"MSE = {mse}, NRMSE = {nrmse}, r2 = {r2}")
    save_score_info(mse, rmse, r2)

    if parameters.get("plot", None) == "regression":
        _regression_plot(Y_test, Y_pred)
    if parameters.get("plot", None) == "time_series":
        _time_series_plot(Y_test, Y_pred)
    return nrmse, r2

def save_score_info(mse, rmse, r2):
    info = {
        'mse': float(mse),
        'rmse': float(rmse),
        'r2': float(r2)
    }
    with open('data/08_reporting/score.yml', 'w') as file:
        yaml.dump(info, file)

def split_data(X, Y, parameters: Dict[str, Any]):
    # Use provided random state or None
    split_time = parameters.get("split_time", None)
    if split_time:
        X_train, X_test = X[:split_time], X[split_time:]
        Y_train, Y_test = Y[:split_time], Y[split_time:]
        return X_train, X_test, Y_train, Y_test
    
    X_train, X_test, Y_train, Y_test = train_test_split(
        X, Y, 
        random_state = parameters.get("random_state", None),
        train_size = parameters.get("train_size", None)
    )
    return X_train, X_test, Y_train, Y_test
