from kedro_umbrella.library import PINNTrainer
import neuromancer as nm
import torch
import numpy as np


class DiffusionPINNTrainer(PINNTrainer):

    def __init__(self, params, **kwargs):
        super().__init__(params, **kwargs)

    def define_neural_network(self):
        input_size = 2
        output_size = 1
        hidden_sizes = [30, 30]

        return nm.modules.blocks.MLP(
            insize=input_size,
            outsize=output_size,
            hsizes=hidden_sizes,
            nonlin=torch.nn.SiLU,
        )

    def define_decision_variables(self):

        x_var = nm.variable("x")
        y_var = nm.variable("y")
        T_var = nm.variable("T")

        return {
            "x": x_var,
            "y": y_var,
            "T": T_var,
        }

    def define_residual_pde(self, decision_vars):

        x, y, T = decision_vars["x"], decision_vars["y"], decision_vars["T"]

        dT_dx = T.grad(x)
        dT_dy = T.grad(y)
        d2T_dx2 = dT_dx.grad(x)
        d2T_dy2 = dT_dy.grad(y)

        f_pinn = d2T_dx2 + d2T_dy2

        return f_pinn

    def define_objective_function(
        self,
        decision_vars,
        residual_pde,
        training_loader,
    ):
        f_pinn = residual_pde

        x, y, T = decision_vars["x"], decision_vars["y"], decision_vars["T"]

        N_bc = self.N_bc
        T_train_bc = self.T_train_bc

        # scaling factor for better convergence
        scaling_cp = 1.0
        scaling_bc = 1.0

        # PDE CP loss (MSE)
        l_cp = scaling_cp * (f_pinn == 0.0) ^ 2

        # PDE BC loss (MSE)
        l_bc = (
            scaling_bc * (T[-N_bc:] == T_train_bc) ^ 2
        )  # remember that we concatenated CP and BC data

        return [l_cp, l_bc]

    def define_constraints(self, decision_vars):

        x, y, T = decision_vars["x"], decision_vars["y"], decision_vars["T"]

        # output constraints to bound the PINN solution
        con_1 = T >= 0  # Passive scalar T is always positive; note: this is optional

        return [con_1]
