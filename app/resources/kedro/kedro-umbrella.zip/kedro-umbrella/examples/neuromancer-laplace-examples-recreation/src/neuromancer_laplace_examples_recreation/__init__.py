"""neuromancer-laplace-examples-recreation
"""

__version__ = "0.1"
