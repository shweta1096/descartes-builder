"""
This is a boilerplate pipeline
generated using Kedro 0.18.8
"""

from kedro.pipeline import Pipeline, node, pipeline

from kedro_umbrella import coder, processor, trainer
from kedro_umbrella.library import *

#from kedro_umbrella import code, process, split, train

#from .nodes import basic_trainer, score, split_data_1, xform_data, generate_fmu_class

# pro => doesn't need to code the node +- => one still need to think in advance
# about wanting to output some valid function that can be called further ahead
# dis => longer pipeline


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            # TRAINING PIPELINE
            processor(
                func=split_data,
                name="split_data",
                inputs=["displ", "eps", "parameters"],
                outputs=["X_train", "X_test", "Y_train", "Y_test"],
            ),
            coder(
                func=xform_data,
                name="xform_X",
                inputs=["X_train", "parameters"],
                outputs=["X_xform", "X_inv_xform"],
            ),
            coder(
                func=xform_data,
                name="xform_Y",
                inputs=["Y_train", "parameters"],
                outputs=["Y_xform", "Y_inv_xform"],
            ),
            processor(
                name="reduce_X", inputs=["X_xform", "X_train"], outputs="X_train_red"
            ),
            processor(
                name="reduce_Y", inputs=["Y_xform", "Y_train"], outputs="Y_train_red"
            ),
            trainer(
                func=basic_trainer,
                name="trainer",
                inputs=["X_train_red", "Y_train_red", "parameters"],
                outputs="regressor",
            ),
            # Generate FMU class and export FMU
            node(
                func=generate_fmu_class,
                inputs=["X_train", "Y_train", "X_xform", "regressor","Y_inv_xform"],
                outputs="script_file_path", 
                name="generate_fmu"
            ),
            # TESTING PIPELINE
            processor(inputs=["X_xform", "X_test"], outputs="X_test_red"),
            processor(inputs=["regressor", "X_test_red"], outputs="Y_pred_red"),
            processor(inputs=["Y_inv_xform", "Y_pred_red"], outputs="Y_pred"),
            node(
                func=score,
                name="score",
                inputs=["Y_test", "Y_pred"],
                outputs=["mse", "r2"],
            ),
        ]
    )
