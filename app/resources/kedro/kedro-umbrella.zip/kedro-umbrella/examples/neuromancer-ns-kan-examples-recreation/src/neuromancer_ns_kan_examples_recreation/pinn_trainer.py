from kedro_umbrella.library import PINNTrainer
import neuromancer as nm
import torch
import numpy as np


class DiffusionPINNTrainer(PINNTrainer):

    def __init__(self, params, **kwargs):
        super().__init__(params, **kwargs)

    def define_neural_network(self):
        input_size = 2
        output_size = 3
        hsizes = [5, 5]
        spline_order = 5

        return nm.modules.blocks.KANBlock(
            insize=input_size,
            outsize=output_size,
            hidden_size=hsizes,
            spline_order=spline_order,
        )

    def define_decision_variables(self):

        # symbolic Neuromancer variables
        U = nm.variable("U")
        vx = nm.variable("U")[:, [0]]
        vy = nm.variable("U")[:, [1]]
        p = nm.variable("U")[:, [2]]
        x = nm.variable("x")  # spatial coordinate 1
        y = nm.variable("y")  # spatial coordinate 2

        return {"x": x, "y": y, "U": U, "vx": vx, "vy": vy, "p": p}

    def define_residual_pde(self, decision_vars):

        Re = self.params["Re"]

        x, y, U, vx, vy, p = (
            decision_vars["x"],
            decision_vars["y"],
            decision_vars["U"],
            decision_vars["vx"],
            decision_vars["vy"],
            decision_vars["p"],
        )

        # get the symbolic derivatives
        dvx_dx = vx.grad(x)
        dvy_dx = vy.grad(x)
        dp_dx = p.grad(x)

        dvx_dy = vx.grad(y)
        dvy_dy = vy.grad(y)
        dp_dy = p.grad(y)

        d2vx_dx2 = dvx_dx.grad(x)
        d2vy_dx2 = dvy_dx.grad(x)
        d2vx_dy2 = dvx_dy.grad(y)
        d2vy_dy2 = dvy_dy.grad(y)

        # get the PINN form
        f_pinn_1 = (
            (1.0 / Re) * (d2vx_dx2 + d2vx_dy2) - vx * dvx_dx - vy * dvx_dy - dp_dx
        )
        f_pinn_2 = (
            (1.0 / Re) * (d2vy_dx2 + d2vy_dy2) - vy * dvy_dx - vy * dvy_dy - dp_dy
        )
        f_pinn_3 = dvx_dx + dvy_dy

        return {
            "f_pinn_1": f_pinn_1,
            "f_pinn_2": f_pinn_2,
            "f_pinn_3": f_pinn_3,
        }

    def define_objective_function(
        self,
        decision_vars,
        residual_pde,
        training_loader,
    ):
        vx, vy, p = decision_vars["vx"], decision_vars["vy"], decision_vars["p"]

        f_pinn_1, f_pinn_2, f_pinn_3 = (
            residual_pde["f_pinn_1"],
            residual_pde["f_pinn_2"],
            residual_pde["f_pinn_3"],
        )

        N_bc, vx_train_bc, vy_train_bc, p_train_bc = (
            self.N_bc,
            self.vx_train_bc,
            self.vy_train_bc,
            self.p_train_bc,
        )

        # scaling factor for better convergence
        scaling_cp = 1.0
        scaling_bc = 1.0
        scaling_continuity = 1.0

        # PDE CP loss (MSE)
        l_cp_1 = scaling_cp * (f_pinn_1 == 0.0) ^ 2
        l_cp_2 = scaling_cp * (f_pinn_2 == 0.0) ^ 2
        l_cp_3 = scaling_continuity * (f_pinn_3 == 0.0) ^ 2
        l_cp_1.update_name("loss_cp_1")
        l_cp_2.update_name("loss_cp_2")
        l_cp_3.update_name("loss_cp_3")

        # PDE BC loss (MSE)
        # note: remember that we concatenated CP and BC
        l_bc_1 = scaling_bc * (vx[-N_bc:] == vx_train_bc) ^ 2
        l_bc_2 = scaling_bc * (vy[-N_bc:] == vy_train_bc) ^ 2
        l_bc_3 = scaling_bc * (p[-N_bc:] == p_train_bc) ^ 2

        l_bc_1.update_name("loss_bc_1")
        l_bc_2.update_name("loss_bc_2")
        l_bc_3.update_name("loss_bc_3")

        return [l_cp_1, l_cp_2, l_cp_3, l_bc_1, l_bc_2, l_bc_3]

    def define_constraints(self, decision_vars):

        return []
