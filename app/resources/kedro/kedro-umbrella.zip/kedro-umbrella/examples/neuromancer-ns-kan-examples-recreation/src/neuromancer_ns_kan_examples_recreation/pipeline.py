from kedro.pipeline import Pipeline, node, pipeline
from kedro_umbrella import coder, processor, trainer
from kedro_umbrella.library import *

from .pinn_trainer import DiffusionPINNTrainer
import torch
from neuromancer.dataset import DictDataset


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            processor(func=load_device, inputs="parameters", outputs="device"),
            processor(
                func=gen_mat,
                inputs="parameters",
                outputs=["X", "Y"],
                name="generate_input_data",
            ),
            processor(
                func=create_training_dataloaders,
                inputs=["X", "Y", "parameters"],
                outputs=[
                    "train_loader",
                    "test_data",
                    "kwargs",
                ],
                name="create_data_loader",
            ),
            trainer(
                func=run_diffusion_pinn_trainer,
                name="trainer",
                inputs=["train_loader", "device", "kwargs", "parameters"],
                outputs="pinn_model_pred",
            ),
            processor(
                func=transform_pred,
                inputs=["pinn_model_pred", "test_data", "parameters"],
                outputs=["vx_pinn", "vy_pinn", "p_pinn"],
            ),
            processor(
                func=plot_heatmap,
                inputs=["X", "Y", "vx_pinn", "vy_pinn", "p_pinn"],
                outputs=None,
                name="plot_heatmap",
            ),
        ]
    )


def gen_mat(
    parameters: Dict[str, Any]
) -> Tuple[np.ndarray | list[np.ndarray], np.ndarray | list[np.ndarray]]:
    # Define number of collocation points in x and y
    Nx = parameters.get("Nx", 50)
    Ny = parameters.get("Ny", 50)

    x = torch.linspace(0, 1, Nx)
    y = torch.linspace(0, 1, Ny)

    X, Y = torch.meshgrid(x, y, indexing="ij")

    return X, Y


def create_training_dataloaders(X, Y, parameters):

    Nx = parameters.get("Nx", 50)
    Ny = parameters.get("Ny", 50)
    N_cp = parameters.get("N_cp", 1000)

    # Reshape tensors to 2D
    X_test = X.reshape(-1, 1)
    Y_test = Y.reshape(-1, 1)

    # Top of lid-driven cavity
    ic_U = torch.zeros(size=(Nx, Ny, 3)) * 0.0
    ic_U[:, -1, 0] = 1.0  # setting v1 = 1 (lid)

    # Left boundary conditions
    left_bc_X = X[[0], :]
    left_bc_Y = Y[[0], :]
    left_bc_vx = ic_U[[0], :, 0]
    left_bc_vy = ic_U[[0], :, 1]
    left_bc_p = ic_U[[0], :, 2]

    # Right boundary conditions
    right_bc_X = X[[-1], :]
    right_bc_Y = Y[[-1], :]
    right_bc_vx = ic_U[[-1], :, 0]
    right_bc_vy = ic_U[[-1], :, 1]
    right_bc_p = ic_U[[-1], :, 2]

    # Top boundary conditions
    top_bc_X = X[:, [-1]]
    top_bc_Y = Y[:, [-1]]
    top_bc_vx = ic_U[:, [-1], 0]
    top_bc_vy = ic_U[:, [-1], 1]
    top_bc_p = ic_U[:, [-1], 2]

    # Bottom boundary conditions
    bottom_bc_X = X[:, [0]]
    bottom_bc_Y = Y[:, [0]]
    bottom_bc_vx = ic_U[:, [0], 0]
    bottom_bc_vy = ic_U[:, [0], 1]
    bottom_bc_p = ic_U[:, [0], 2]

    X_train_bc = torch.concat(
        [
            left_bc_X.flatten(),
            right_bc_X.flatten(),
            top_bc_X.flatten(),
            bottom_bc_X.flatten(),
        ]
    ).view((-1, 1))
    Y_train_bc = torch.concat(
        [
            left_bc_Y.flatten(),
            right_bc_Y.flatten(),
            top_bc_Y.flatten(),
            bottom_bc_Y.flatten(),
        ]
    ).view((-1, 1))
    vx_train_bc = torch.concat(
        [
            left_bc_vx.flatten(),
            right_bc_vx.flatten(),
            top_bc_vx.flatten(),
            bottom_bc_vx.flatten(),
        ]
    ).view((-1, 1))
    vy_train_bc = torch.concat(
        [
            left_bc_vy.flatten(),
            right_bc_vy.flatten(),
            top_bc_vy.flatten(),
            bottom_bc_vy.flatten(),
        ]
    ).view((-1, 1))
    p_train_bc = torch.concat(
        [
            left_bc_p.flatten(),
            right_bc_p.flatten(),
            top_bc_p.flatten(),
            bottom_bc_p.flatten(),
        ]
    ).view((-1, 1))

    N_bc = X_train_bc.shape[0]

    # Domain bounds
    x_lb = X_test[0]
    x_ub = X_test[-1]
    y_lb = Y_test[0]
    y_ub = Y_test[-1]

    # Generate collocation points (CP)
    X_train_cp = torch.FloatTensor(N_cp, 1).uniform_(float(x_lb), float(x_ub))
    Y_train_cp = torch.FloatTensor(N_cp, 1).uniform_(float(y_lb), float(y_ub))

    # Append collocation points and boundary points for training
    X_train = torch.vstack((X_train_cp, X_train_bc)).float()
    Y_train = torch.vstack((Y_train_cp, Y_train_bc)).float()

    # turn on gradients for PINN
    X_train.requires_grad = True
    Y_train.requires_grad = True

    train_data = DictDataset(
        {
            "x": X_train,
            "y": Y_train,
        },
        name="train",
    )

    test_data = DictDataset({"x": X_test, "y": Y_test}, name="test")

    train_loader = torch.utils.data.DataLoader(
        train_data,
        batch_size=X_train.shape[0],
        collate_fn=train_data.collate_fn,
        shuffle=False,
    )

    return (
        train_loader,
        test_data,
        {
            "N_bc": N_bc,
            "vx_train_bc": vx_train_bc,
            "vy_train_bc": vy_train_bc,
            "p_train_bc": p_train_bc,
        },
    )


def run_diffusion_pinn_trainer(train_loader, device: torch.device, kwargs, parameters):
    trainer = DiffusionPINNTrainer(params=parameters, **kwargs)

    return trainer.train(training_loader=train_loader, device=device)


def transform_pred(funct, test_data, parameters):
    Nx = parameters.get("Nx", 50)
    Ny = parameters.get("Ny", 50)

    U_pinn = funct(test_data.datadict)["U"]

    # arrange data for plotting
    vx_pinn = U_pinn[:, 0].reshape(shape=[Nx, Ny]).detach().cpu()
    vy_pinn = U_pinn[:, 1].reshape(shape=[Nx, Ny]).detach().cpu()
    p_pinn = U_pinn[:, 2].reshape(shape=[Nx, Ny]).detach().cpu()

    return vx_pinn, vy_pinn, p_pinn


def plot_heatmap(X, Y, vx_pinn, vy_pinn, p_pinn):
    # plot PINN solution
    fig = plt.figure(figsize=(20, 6))

    # # Plot for the second heatmap (PINN solution)
    ax2 = plt.subplot(1, 3, 1)
    CP2 = plt.contourf(X, Y, vx_pinn, levels=20, cmap="viridis")
    plt.title("PIKAN solution, $v_x$")
    plt.xlabel("$x$")
    plt.ylabel("$y$")
    plt.colorbar(CP2, label="$v_x$")
    ax2.set_aspect("equal", adjustable="box")

    ax2 = plt.subplot(1, 3, 2)
    CP2 = plt.contourf(X, Y, vy_pinn, levels=20, cmap="viridis")
    plt.title("PIKAN solution, $v_y$")
    plt.xlabel("$x$")
    plt.ylabel("$y$")
    plt.colorbar(CP2, label="$v_y$")
    ax2.set_aspect("equal", adjustable="box")

    ax2 = plt.subplot(1, 3, 3)
    CP2 = plt.contourf(X, Y, p_pinn, levels=20, cmap="viridis")
    plt.title("PIKAN solution, $p$")
    plt.xlabel("$x$")
    plt.ylabel("$y$")
    plt.colorbar(CP2, label="$p$")
    ax2.set_aspect("equal", adjustable="box")

    fig.tight_layout()

    output_path: str = "./data/07_model_output"
    file_name: str = "PIKAN_solution"
    file_type: Literal["png", "jpg", "jpeg"] = "png"

    if not os.path.exists(output_path):
        os.makedirs(output_path)

    plt.savefig(f"{output_path}/{file_name}.{file_type}")
    logger.info(f"Plot saved at {output_path}/{file_name}.{file_type}")

    plt.close()
