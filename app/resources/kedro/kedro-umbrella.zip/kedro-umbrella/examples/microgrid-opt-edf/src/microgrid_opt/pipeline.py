"""
This is a boilerplate pipeline
generated using Kedro 0.18.8
"""

from kedro.pipeline import Pipeline, node, pipeline
from kedro_umbrella import coder, processor, trainer
from kedro_umbrella.library import *

# pro => doesn't need to code the node +- => one still need to think in advance
# about wanting to output some valid function that can be called further ahead
# dis => longer pipeline

def preproc_data(raw_data):
    X = raw_data['input'][:]
    y = raw_data['output'][:]
    return X, y

def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            # TRAINING PIPELINE
            processor(
               func=preproc_data,
               inputs=["raw_data"],
               outputs=["X", "Y"]
            ),
            processor(
                func=split_data,
                name="split_data",
                inputs=["X", "Y", "parameters"],
                outputs=["X_train", "X_test", "Y_train", "Y_test"],
            ),
            coder(
                func=xform_data,
                name="xform_Y",
                inputs=["Y_train", "parameters"],
                outputs=["Y_xform", "Y_inv_xform"],
            ),
            processor(
                name="reduce_Y", inputs=["Y_xform", "Y_train"], outputs="Y_train_red"
            ),
            trainer(
                func=basic_trainer,
                name="trainer",
                inputs=["X_train", "Y_train_red", "parameters"],
                outputs="regressor",
            ),
            # TESTING PIPELINE
            processor(inputs=["regressor", "X_test"], outputs="Y_pred_red"),
            processor(inputs=["Y_inv_xform", "Y_pred_red"], outputs="Y_pred"),
            processor(
                func=score,
                name="score",
                inputs=["Y_test", "Y_pred"],
                outputs=["nmrse", "r2"],
            ),
        ]
    )
