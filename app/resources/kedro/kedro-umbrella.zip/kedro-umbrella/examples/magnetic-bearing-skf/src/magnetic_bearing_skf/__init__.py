"""magnetic-bearing-skf
"""

__version__ = "0.1"
