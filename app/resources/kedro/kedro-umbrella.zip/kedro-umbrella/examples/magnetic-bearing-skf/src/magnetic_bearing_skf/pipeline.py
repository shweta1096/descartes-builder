"""
This is a boilerplate pipeline
generated using Kedro 0.18.14
"""

from kedro.pipeline import Pipeline

from kedro.pipeline.modular_pipeline import pipeline

from kedro_umbrella import coder, processor, trainer
from kedro_umbrella.library import *
import numpy as np
SPLIT_TIME = 400

def preproc_ef_data(SolEF):
    Flux_EF = SolEF["Sol"]["flux"][()].reshape(-1,1)
    return Flux_EF

def preproc_cauer_data(SolCauer):
    X_train = SolCauer['X_train'][:] # time and voltage
    flux_cauer = SolCauer['Y_train'][:] # flux cauer

    #time = X_train[:,0].reshape(-1,1)
    voltage = X_train[:,1].reshape(-1,1)
    current = X_train[:,2].reshape(-1,1)
    X = np.hstack([current, voltage])
    return X, flux_cauer

def create_pipeline(**kwargs) -> Pipeline:
    preproc_pipe = pipeline(
        pipe = [
            processor(
                func = preproc_ef_data,
                inputs = "FEM_data",
                outputs = "flux_FE",
            ),
            processor(
                func = preproc_cauer_data,
                inputs = "cauer_data",
                outputs = ["X", "flux_cauer"],
            ),
            processor(
                func = np.subtract,
                inputs = ["flux_FE", "flux_cauer"],
                outputs = "flux_err",
            ),
            processor(
                func = split_data,
                inputs = ["X", "flux_err", "parameters"],
                outputs = ["X_train", "X_test", "Y_train", "Y_test"],
            )
        ],
        inputs = ["FEM_data", "cauer_data"],
        outputs=["X_train", "X_test", "Y_train", "Y_test"],
        namespace = "preproc"
    )

    dual_proc = pipeline(
        pipe = [   
            coder(
                func=xform_data,
                name="xform_X",
                inputs=["X_train", "parameters"],
                outputs=["X_xform", "X_inv_xform"],
            ),
            coder(
                func=xform_data,
                name="xform_Y",
                inputs=["Y_train", "parameters"],
                outputs=["Y_xform", "Y_inv_xform"],
            ),
            processor(
                name="reduce_X", inputs=["X_xform", "X_train"], outputs="X_train_red"
            ),
            processor(
                name="reduce_Y", inputs=["Y_xform", "Y_train"], outputs="Y_train_red"
            )
        ],
        inputs=["X_train", "Y_train"],
        outputs=["X_train_red", "Y_train_red", "X_xform", "Y_inv_xform"],
        namespace="dual_proc"
    )
    
    train_template = pipeline([
            trainer(
                func=basic_trainer,
                name="trainer",
                inputs=["X_train_red", "Y_train_red", "params:trainer"],
                outputs="regressor",
            ),
            # TESTING PIPELINE
            processor(inputs=["X_xform", "X_test"], outputs="X_test_red"),
            processor(inputs=["regressor", "X_test_red"],
                        outputs="Y_pred_red"),
            processor(inputs=["Y_inv_xform", "Y_pred_red"], outputs="Y_pred"),
            processor(
                func=score1,
                name="score",
                inputs=["Y_test", "Y_pred"],
                outputs="mse",
            ),
        ])

    train1 =  pipeline(
        pipe = train_template,
        inputs=["X_train_red", "Y_train_red", "X_test", "Y_test", "X_xform", "Y_inv_xform"],
        parameters={"params:trainer": "params:trainer1"},
        namespace = "train1")
    
    train2 =  pipeline(
        pipe = train_template,
        inputs=["X_train_red", "Y_train_red", "X_test", "Y_test", "X_xform", "Y_inv_xform"],
        parameters={"params:trainer": "params:trainer2"},
        namespace = "train2")

    return preproc_pipe + dual_proc + train1 + train2

