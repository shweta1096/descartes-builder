# import for matread and linear_interpolation
using MAT
using Interpolations
# import for diagm
using LinearAlgebra
# import for ODEProblem and ODEFunction
using DifferentialEquations
using Plots
# serialization
using JLD2
using FileIO


function load_cauer_data()
    # load data
    # the Cauer here has 8 entries
    # XXX each line is 8x41 meaning that there are 41 simulations used here???
    Cauer = matread("../data/01_raw/cauer_multiple.mat")
    # applied current to the system? I don't really get what this is exactly
    I_range = Cauer["I_range"] 
    L = Cauer["Lind_tot"]
    R = Cauer["R_tot"];
    Flux_range = reduce(vcat,Cauer["Fflux"]) 
    Flux_range = Flux_range[:,1].*I_range[:]
    
    # interpolate indutance
    # mirrors the array around the middle
    # I_range will go from 0:40 to -40:40 
    #   I_range[-40] => L_range[40]
    #   I_range[40]  => L_range[40]
    # possibly because current sign value is totally arbitrary
    L_inter=linear_interpolation(
        [-I_range[end:-1:2];I_range[1:end]], # -40:40
        [eachcol([L[:,end:-1:2];;L[:,:]])...], 
        extrapolation_bc = Interpolations.Flat())

    # interpolate resistance
    R = Cauer["R_tot"];
    R_inter = linear_interpolation(
        [-I_range[end:-1:2];I_range[1:end]],
        [eachcol([R[:,end:-1:2];;R[:,:]])...], 
        extrapolation_bc = Interpolations.Flat());

    n_Cauer=Int(Cauer["N_CC"]);
    Mphi_inv = tril(ones(n_Cauer,n_Cauer));
        
    return R_inter, L_inter, Mphi_inv, n_Cauer
end

function load_fem_data()
    SolEF = matread("../data/01_raw/Test_I0_15_mv_sin_nl_5_multistep_30Amax_500.mat")

    Flux_EF = SolEF["Sol"]["flux"][:,1] # just one entry anyway
    I_EF = SolEF["Sol"]["courant"][:,1]
    t_EF = SolEF["Sol"]["t"][:,1]
    V_EF = SolEF["Sol"]["tension"][:,1]
    return Flux_EF, I_EF, t_EF, V_EF
end

function f_t_ref(du,u,p,t)
    L_inv = 1 ./(L_inter(u[n_Cauer+1]) );
    R_tmp = R_inter(u[n_Cauer+1])
    R = diagm(R_tmp[:])*triu(ones(n_Cauer,n_Cauer));
    du[1:n_Cauer] = Mphi_inv *(-R*(L_inv[:].*u[1:n_Cauer])+ [Voltage(t);zeros(n_Cauer-1)]);
    du[n_Cauer+1] = u[n_Cauer+1]-sum(L_inv.*u[1:n_Cauer]);
end

function calculate_cauer(n_Cauer, Flux_EF, I_EF, t_EF, V_EF, dt_EF)
    # mass matrix
    M = one(zeros(n_Cauer+1, n_Cauer+1))
    M[n_Cauer+1,n_Cauer+1] = 0

    # initial conditions 
    u0 = zeros(n_Cauer+1)
    u0[1] = Flux_EF[1,1]
    u0[n_Cauer+1] = I_EF[1,1]

    # solution for Cauer: system properties to flux (Phi) from IC
    f_t_refODE = ODEFunction(f_t_ref, mass_matrix = M)
    prob = ODEProblem(f_t_refODE, u0,(0, t_EF[end]))
    result = Array(solve(prob,Rodas5(),saveat = dt_EF, dt = dt_EF))
    Phi = result[1,:]
    I_Cauer = result[n_Cauer+1,:]

    X_train = [t_EF'; Voltage.(t_EF)'; I_Cauer']
    Y_train = Phi
    return X_train, Y_train
end

R_inter, L_inter, Mphi_inv, n_Cauer = load_cauer_data()

Flux_EF, I_EF, t_EF, V_EF = load_fem_data()
dt_EF = t_EF[2] - t_EF[1]
Voltage(x) = constant_interpolation(t_EF, V_EF, extrapolation_bc = Interpolations.Flat())(x);
#plot(t_EF,Voltage.(t_EF))

X_train, Y_train = calculate_cauer(n_Cauer, Flux_EF, I_EF, t_EF, V_EF, dt_EF)

# serialize data for python
@save "cauer_data.jld2" X_train Y_train




