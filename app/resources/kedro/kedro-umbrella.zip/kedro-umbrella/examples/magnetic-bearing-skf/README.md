# Magnetic bearing use case 

To run the pipeline, use the Makefile accordingly. Different rules are provided. 

This example focuses on active magnetic bearing. The goal is to predict the
induced magnetic flux based on the current & voltage applied to the device. 

          X                         Y
    Current, Voltage -> Model -> FluxErr + FluxCauer -> FluxPred

The pipeline proceeds as follows: 

1. Preprocesing
    a) Load and preprocess data from finite element method (FEM) and Cauer solution
   (simplified physics model)
   b) Subtract FE - Cauer to obtain the error (what Cauer can't account for in
   FE). We learn the error as per hybrid AI paradigm. 

2. Encoding of data. Reduce the dimensionality of X and Y to obtain reduced
   basis.

3. Train of model. Train and evaluate the model. X and Y are decoded back
   before evaluation to ensure score is calculate in the proper scale (and is
   comparable across models).
