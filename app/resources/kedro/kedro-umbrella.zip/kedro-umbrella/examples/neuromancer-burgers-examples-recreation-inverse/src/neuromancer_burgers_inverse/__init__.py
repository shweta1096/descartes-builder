"""neuromancer-burgers-inverse
"""

__version__ = "0.1"
