from kedro_umbrella.library import PINNTrainer
import neuromancer as nm
import torch
import numpy as np


class DiffusionPINNTrainer(PINNTrainer):

    def __init__(self, params, **kwargs):
        super().__init__(params, **kwargs)

    def define_neural_network(self):
        input_size = 2
        output_size = 1
        hidden_sizes = [32, 32]

        return nm.modules.blocks.MLP(
            insize=input_size,
            outsize=output_size,
            hsizes=hidden_sizes,
            nonlin=torch.nn.Tanh,
        )

    def define_decision_variables(self):

        x_var = nm.variable("x")
        t_var = nm.variable("t")
        u_var = nm.variable("u")
        u_hat_var = nm.variable("u_hat")

        # trainable parameters with initial values
        lamb = nm.variable(
            torch.nn.Parameter(torch.tensor(2.0)), display_name="lambda"
        )  # trainable PDE parameter lambda
        nu = nm.variable(
            torch.nn.Parameter(torch.tensor(0.01)), display_name="nu"
        )  # trainable PDE parameter nu

        return {
            "x": x_var,
            "t": t_var,
            "u": u_var,
            "u_hat": u_hat_var,
            "lambda": lamb,
            "nu": nu,
        }

    def define_residual_pde(self, decision_vars):

        x, t, u_hat = decision_vars["x"], decision_vars["t"], decision_vars["u_hat"]

        lamb, nu = decision_vars["lambda"], decision_vars["nu"]

        du_dt = u_hat.grad(t)
        du_dx = u_hat.grad(x)
        d2u_dx2 = du_dx.grad(x)

        f_pinn = du_dt + lamb * u_hat * du_dx - nu * d2u_dx2

        return f_pinn

    def define_objective_function(
        self,
        decision_vars,
        residual_pde,
        training_loader,
    ):
        scaling = 1000.0  # Scaling factor for better convergence

        f_pinn = residual_pde
        u = decision_vars["u"]
        u_hat = decision_vars["u_hat"]

        # PDE CP loss
        ell_f = (f_pinn == 0.0) ^ 2

        # PDE IC and BC loss
        ell_u = scaling * (u_hat == u) ^ 2  # remember we stacked CP with IC and BC
        return [ell_f, ell_u]

    def define_constraints(self, decision_vars):
        scaling = 1000.0

        u_hat = decision_vars["u_hat"]

        # Output constraints to bound the PINN solution in the PDE output domain [-1.0, 1.0]
        con_1 = scaling * (u_hat <= 1.0) ^ 2
        con_2 = scaling * (u_hat >= -1.0) ^ 2

        return [con_1, con_2]

    def define_inverse_problem(self, decision_vars):
        lamb, nu = decision_vars["lambda"], decision_vars["nu"]

        self.logger.info("True parameter lambda = 1.0")
        self.logger.info("Estimated parameter lambda = {}".format(float(lamb.value)))
        self.logger.info("True parameter nu = {}".format(0.01 / np.pi))
        self.logger.info("Estimated parameter nu = {}".format(float(nu.value)))
