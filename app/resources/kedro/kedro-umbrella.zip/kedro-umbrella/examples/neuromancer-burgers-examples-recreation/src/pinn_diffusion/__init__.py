"""pinn-diffusion
"""

__version__ = "0.1"
