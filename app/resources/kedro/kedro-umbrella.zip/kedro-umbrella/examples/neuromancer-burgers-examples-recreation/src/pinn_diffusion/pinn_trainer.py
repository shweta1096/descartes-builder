from kedro_umbrella.library import PINNTrainer
import neuromancer as nm
import torch
import numpy as np


class DiffusionPINNTrainer(PINNTrainer):

    def __init__(self, params, **kwargs):
        super().__init__(params, **kwargs)

    def define_neural_network(self):
        input_size = 2
        output_size = 1
        hidden_sizes = [32, 32]

        return nm.modules.blocks.MLP(
            insize=input_size,
            outsize=output_size,
            hsizes=hidden_sizes,
            nonlin=torch.nn.Tanh,
        )

    def define_decision_variables(self):

        x_var = nm.variable("x")
        t_var = nm.variable("t")
        u_var = nm.variable("u")

        return {"x": x_var, "t": t_var, "u": u_var}

    def define_residual_pde(self, decision_vars):

        x, t, u = decision_vars["x"], decision_vars["t"], decision_vars["u"]

        nu = 0.01 / np.pi

        du_dt = u.grad(t)
        du_dx = u.grad(x)
        d2u_dx2 = du_dx.grad(x)

        f_pinn = du_dt + u * du_dx - nu * d2u_dx2

        return f_pinn

    def define_objective_function(
        self,
        decision_vars,
        residual_pde,
        training_loader,
    ):
        scaling = 100.0  # Scaling factor for better convergence
        Nu = 200  # Number of initial conditions

        f_pinn = residual_pde
        y_hat = decision_vars["u"]

        # PDE CP loss
        ell_f = scaling * (f_pinn == 0.0) ^ 2

        # Extract training data
        Y_train_Nu = self.Y_train_Nu

        # PDE IC and BC loss
        ell_u = (
            scaling * (y_hat[-Nu:] == Y_train_Nu) ^ 2
        )  # remember we stacked CP with IC and BC
        return [ell_f, ell_u]

    def define_constraints(self, decision_vars):
        scaling = 100.0

        y_hat = decision_vars["u"]

        # Output constraints to bound the PINN solution in the PDE output domain [-1.0, 1.0]
        con_1 = scaling * (y_hat <= 1.0) ^ 2
        con_2 = scaling * (y_hat >= -1.0) ^ 2

        return [con_1, con_2]
