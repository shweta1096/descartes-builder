from kedro.pipeline import Pipeline, node, pipeline
from kedro_umbrella import coder, processor, trainer
from kedro_umbrella.library import *

from .pinn_trainer import DiffusionPINNTrainer
import torch
from neuromancer.dataset import DictDataset


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            processor(func=load_device, inputs="parameters", outputs="device"),
            processor(
                func=load_mat, inputs="parameters", outputs=["raw_input", "raw_output"]
            ),
            processor(
                func=load_raw_data,
                inputs=["raw_input", "raw_output", "parameters"],
                outputs=["X", "T", "Y"],
                name="load_raw_data",
            ),
            processor(
                func=create_training_dataloaders,
                inputs=["X", "T", "Y", "parameters"],
                outputs=[
                    "train_loader",
                    "test_data",
                    "kwargs",
                ],
                name="create_data",
            ),
            trainer(
                func=run_diffusion_pinn_trainer,
                name="trainer",
                inputs=["train_loader", "device", "kwargs", "parameters"],
                outputs="pinn_model_pred",
            ),
            processor(
                func=transform_pred,
                inputs=["pinn_model_pred", "test_data", "parameters"],
                outputs="Y_pred",
            ),
            processor(
                func=score,
                name="score",
                inputs=["Y", "Y_pred"],
                outputs=["nrmse", "r2"],
            ),
            processor(
                func=plot3D,
                inputs=["X", "T", "Y"],
                outputs=None,
            ),
            processor(
                func=plot3dDiff,
                inputs=["X", "T", "Y", "Y_pred"],
                outputs=None,
            ),
        ]
    )


def load_raw_data(
    raw_X: np.ndarray | list[np.ndarray],
    raw_Y: np.ndarray | list[np.ndarray],
    parameters: Dict[str, Any],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    x, t = raw_X[0], raw_X[1]
    ysol = raw_Y[0]

    X, T = np.meshgrid(x, t)
    X = torch.tensor(X.T).float()
    T = torch.tensor(T.T).float()
    Y = torch.tensor(ysol).float()

    return X, T, Y


def create_training_dataloaders(X, T, Y, parameters):
    Nu = parameters.get("Nu", 200)
    Nf = parameters.get("Nf", 1000)
    batch_size = parameters.get("batch_size", None)

    X_test = X.reshape(-1, 1)
    T_test = T.reshape(-1, 1)
    Y_test = Y.reshape(-1, 1)

    left_X = X[:, [0]]
    left_T = T[:, [0]]
    left_Y = -torch.sin(np.pi * left_X[:, 0]).unsqueeze(1)

    bottom_X = X[[0], :].T
    bottom_T = T[[0], :].T
    bottom_Y = torch.zeros(bottom_X.shape[0], 1)

    top_X = X[[-1], :].T
    top_T = T[[-1], :].T
    top_Y = torch.zeros(top_X.shape[0], 1)

    X_train = torch.vstack([left_X, bottom_X, top_X])
    T_train = torch.vstack([left_T, bottom_T, top_T])
    Y_train = torch.vstack([left_Y, bottom_Y, top_Y])

    idx = np.sort(np.random.choice(X_train.shape[0], Nu, replace=False))
    X_train_Nu = X_train[idx, :].float()
    T_train_Nu = T_train[idx, :].float()
    Y_train_Nu = Y_train[idx, :].float()

    x_lb = X_test[0]
    x_ub = X_test[-1]

    t_lb = T_test[0]
    t_ub = T_test[-1]

    X_train_CP = torch.FloatTensor(Nf, 1).uniform_(float(x_lb), float(x_ub))
    T_train_CP = torch.FloatTensor(Nf, 1).uniform_(float(t_lb), float(t_ub))

    X_train_Nf = torch.vstack((X_train_CP, X_train_Nu)).float()
    T_train_Nf = torch.vstack((T_train_CP, T_train_Nu)).float()

    X_train_Nf.requires_grad = True
    T_train_Nf.requires_grad = True

    train_data = DictDataset(
        {
            "x": X_train_Nf,
            "t": T_train_Nf,
        },
        name="train",
    )

    test_data = DictDataset({"x": X_test, "t": T_test, "y": Y_test}, name="test")

    train_loader = torch.utils.data.DataLoader(
        train_data,
        batch_size=X_train_Nf.shape[0],
        collate_fn=train_data.collate_fn,
        shuffle=False,
    )

    return (
        train_loader,
        test_data,
        {"Y_train_Nu": Y_train_Nu},
    )


def run_diffusion_pinn_trainer(train_loader, device: torch.device, kwargs, parameters):
    trainer = DiffusionPINNTrainer(params=parameters, **kwargs)

    return trainer.train(training_loader=train_loader, device=device)


def transform_pred(funct, test_data, parameters):
    return funct(test_data.datadict)["u"].reshape(shape=[256, 100]).detach().cpu()


def plot3D(X, T, Y):

    plot_2D3D(X, T, Y, "x", "t", "u(x,t)", file_name="model_pred_output")


def plot3dDiff(X, T, y_real, y_pred):

    Y = y_pred - y_real

    plot_2D3D(X, T, Y, "x", "t", "u(x,t)", file_name="model_diff_output")
